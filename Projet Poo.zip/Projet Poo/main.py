from datetime import date
from model.Unit import Unit
from model.LeaseContract import LeaseContract
from model.UnitAssignment import UnitAssignment
from model.TypeBail import Typebail
from User.LeaseClerk import LeaseClerk
from User.LeaseManager import LeaseManager
from User.LeaseManagerSupervisor import LeaseManagerSupervisor
from exception.ValidationException import ValidationException
from exception.PermissionException import PermissionException

def main():
    clerk = LeaseClerk("U001", "David")
    manager = LeaseManager("U002", "Jeremy")
    supervisor = LeaseManagerSupervisor("U003", "Ana")

    print("\n--- Profils Utilisateurs ---")
    clerk.afficher_profil()
    manager.afficher_profil()
    supervisor.afficher_profil()


    print("\n--- Test 1 : Création d'unité par LeaseClerk ---")
    clerk.A_la_permission("creer_unit")
    try:
        unit1 = Unit("U100", "Appartement Luxe", "canada", "quebec", "A", 3, 2, True, True, 46.8139, -71.2080)
        unit1.estValide()
    except ValidationException as e:
        print("ValidationException:", e)

    print("\n--- Test 2 : Modification d'unité par LeaseManager ---")
    try:
        manager.A_la_permission("modifier_unit")
        unit1.nom = "Appartement Ultra Luxe"
        print("Nom modifié:", unit1.nom)
    except PermissionException as e:
        print("PermissionException:", e)

    print("\n--- Test 3 : Création de contrat par LeaseManager ---")
    try:
        manager.A_la_permission("creer_contrat")
        contract1 = LeaseContract(manager, Typebail.LONG_TERM, "Contrat long terme test", [])
        print("Contrat créé:", contract1.id, "-", contract1.typebail)
    except Exception as e:
        print("Erreur création contrat:", e)

    print("\n--- Test 4 : Création d'affectation par LeaseManagerSupervisor ---")
    supervisor.A_la_permission("creer_unit_assignment")
    try:
        assign1 = UnitAssignment(unit1, contract1, 1500, date(2024,1,1), date(2024,12,31), [])
        contract1.AjouterAffectation(assign1)
        print("Affectation créée:", assign1.id, "| Montant total estimé:", assign1.calculer_facture_estimee())
    except Exception as e:
        print("Erreur affectation:", e)


    print("\n--- Test 5 : superposition d'affectations ---")
    try:
        precedent = []
        assign2 = UnitAssignment(unit1, contract1, 1600, date(2024,6,1), date(2024,8,31), precedent)
        if (assign2.dateDebut <= assign1.dateFin and assign1.dateDebut <= assign2.dateFin):
            raise ValidationException("Une unité ne peut être affectée à deux contrats actifs en même temps")
    except ValidationException as e:
        print("ValidationException:", e)

    print("\n--- Test 6 : Contrat sans affectation ---")
    try:
        empty_contract = LeaseContract(manager, Typebail.SHORT_TERM, "Contrat vide", [])
        if not empty_contract.estValide():
            raise ValidationException("Un contrat sans affectation n'est pas valide")
    except ValidationException as e:
        print("ValidationException:", e)

    print("\n--- Test 7 : Suppression par LeaseClerk (non autorisé) ---")
    clerk.A_la_permission("delete_unit")

if __name__ == "__main__":
    main()
