from User.Utilisateur import Utilisateur
from exception.PermissionException import PermissionException

class LeaseManager(Utilisateur):
    def __init__(self, id, nom):
        super().__init__(id, nom, "LeaseManager")

    def A_la_permission(self, action) :
        actions_autorisees = [
            "creer_unit",
            "creer_unit_assignment",
            "creer_contrat",
            "modifier_unit",
            "modifier_assignment"
        ]
        if action in actions_autorisees :
            return print("Vous êtez autoriser")
        else :
            return PermissionException(self.nom)