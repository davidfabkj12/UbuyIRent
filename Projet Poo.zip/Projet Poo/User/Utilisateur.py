from abc import ABC, abstractmethod

class Utilisateur(ABC):
    def __init__(self, id, nom, role):
        self.id = id
        self.nom = nom
        self.role = role

    @abstractmethod
    def A_la_permission(self, action) -> bool:
        pass

    def afficher_profil(self):
        print(f"Utilisateur: {self.nom} | ID: {self.id} | Rôle: {self.role}")

