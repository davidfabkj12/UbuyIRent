from User.Utilisateur import Utilisateur

class LeaseManagerSupervisor(Utilisateur):
    def __init__(self, id, nom):
        super().__init__(id, nom, "LeaseManagerSupervisor")

    def A_la_permission(self, action):
        return print("Vous êtez autoriser")