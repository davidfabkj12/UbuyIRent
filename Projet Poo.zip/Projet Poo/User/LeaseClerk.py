from exception.PermissionException import PermissionException
from User.Utilisateur import Utilisateur


class LeaseClerk(Utilisateur):
    def __init__(self, id, nom):
        super().__init__(id, nom, "LeaseClerk")

    def A_la_permission(self, action) :
        actions_autorisees = [
            "creer_unit",
            "creer_unit_assignment",
            "modifier_dates_assignment"
        ]
        if action in actions_autorisees :
            return print("Vous êtez autoriser")
        else :
            return print(PermissionException(self.nom))
        
    