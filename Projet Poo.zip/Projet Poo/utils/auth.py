import re
import os

fichier = "users.txt"

def inscription_utilisateur():
    print("\n--- INSCRIPTION ---")

    nom = input("Nom : ").strip()
    role = input("Rôle (LeaseClerk / LeaseManager / LeaseManagerSupervisor) : ").strip()
    mot_de_passe = input("Mot de passe : ").strip()

    if role not in ["LeaseClerk", "LeaseManager", "LeaseManagerSupervisor"]:
        print("[Erreur] Rôle non reconnu.")
        return

    nouveau_id = "U001"
    if os.path.exists(fichier):
        with open(fichier, "r") as f:
            lignes = f.readlines()
            ids = [int(re.match(r"id:U(\d+);", ligne).group(1)) for ligne in lignes if re.match(r"id:U(\d+);", ligne)]
            if ids:
                dernier_id = max(ids)
                nouveau_id = f"U{dernier_id + 1:03d}"

    with open(fichier, "a") as f:
        f.write(f"id:{nouveau_id};nom:{nom};role:{role};password:{mot_de_passe}\n")

    print(f"[Succès] Utilisateur {nom}, ")
    
    
    
def connexion_utilisateur():
    print("\n--- CONNEXION ---")

    id_user = input("ID utilisateur : ").strip()
    mot_de_passe = input("Mot de passe : ").strip()

    with open(fichier, "r") as f:
        lignes = f.readlines()
        for ligne in lignes:
            ligne = ligne.strip()
            match = re.match(
                r"id:(U\d{3});nom:(.*?);role:(.*?);password:(.*)", ligne
            )
            if match:
                id_enreg, nom, role, mdp = match.groups()
                if id_enreg == id_user and mdp == mot_de_passe:
                    print(f"[Connexion réussie] Bienvenue {nom} ({role})")
                    return {"id": id_enreg, "nom": nom, "role": role}
    
    print("[Erreur] Identifiants incorrects.")
    return None