from model.UnitAssignment import UnitAssignment
from model.TypeBail import Typebail
import uuid

class LeaseContract :
  t = 1000
  def __init__(self, landlord, typebail, notes, listeAffectations):
    self.id = self.genererID()
    self.landlord = landlord
    self.typebail = typebail
    self.notes = notes if len(notes)<= 4000 else notes[:4000]
    self.listeAffectations = listeAffectations

  def AjouterAffectation(self, affectation):
      
    self.listeAffectations.append(affectation)
    
  def genererID(self):
    id = f"""LEACON-{LeaseContract.t}"""
    LeaseContract.t += 1
    return id
  def estValide(self):
      return len(self.listeAffectations) >0
