from exception.ValidationException import ValidationException
#Notre Classe Unit
class Unit : 
  def __init__(self, id, nom, pays, etatProvince, classe, nbChambres, nbSallesDeBain, wifi, climatisation, longitude, latitude):
    self.id = id
    self.nom = nom
    self.pays = pays
    self.etatProvince = etatProvince
    self.classe = classe
    self.nbChambres = nbChambres
    self.nbSallesDeBain = nbSallesDeBain
    self.wifi = wifi
    self.climatisation = climatisation
    self.longitude = longitude
    self.latitude = latitude
    
#Cette méthode nous perment d'afficher tout les details sur le Units 
  def afficherDetails(self):
    print(f"""________ Détails de l'appartement {self.nom}""")
    print(f"""________ Pays / Province : {self.pays}, {self.etatProvince}""")
    print(f"""________ Classe: {self.classe}""")
    print(f"""________ Chambres : {self.nbChambres}, Salle de bain: {self.nbSallesDeBain}""")
    print(f"""________ Wifi: {self.wifi}""")
    print(f"""________ Climatisation: {self.climatisation}""")
    print(f"""________ lien pour la geolacalisation : {self.genererLien()}""")

#Cette méthode nous perment de générer le lien vers google maps
  def genererLien(self):
    return f"""https://www.google.com/maps?q={self.latitude},{self.longitude}"""

#Cette méthode verifie la validité du Units
  def estValide(self):
    paysValide = ["canada", "usa", "france"]
    provinceValide = {
        "canada" : ["quebec", "ontario", "alberta"],
        "usa" : ["californie", "texas", "new york"],
        "france" : ["île-de-france", "provence", "occitanie"]
    }
    
    if self.pays not in paysValide :
        return print(ValidationException("votre pays n'est pas valide"))
    if self.etatProvince not in provinceValide.get(self.pays, []):
        return print(ValidationException("votre province n'est pas valide"))
    if self.nbChambres <= 0 or self.nbSallesDeBain <= 0:
        return print(ValidationException("le nombre de Chambre/Salle de bain est inferieur ou égale à 0"))
    return print("votre unité a été sauvegaré")
