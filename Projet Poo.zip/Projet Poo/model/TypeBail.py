from enum import Enum

class Typebail(Enum):
    LONG_TERM = "Long-term"
    SHORT_TERM = "Short-term"
    STUDENT = "Student"
    
    def __str__(self):
        return self.value