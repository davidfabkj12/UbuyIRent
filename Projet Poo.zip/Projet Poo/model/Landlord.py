from model.Unit import Unit
from model.LeaseContract import LeaseContract

class Landlord:
    def __init__(self, id, nom):
        self.id = id
        self.nom = nom
        self.liste_unites = []         
        self.liste_contrats = []        

    def ajouter_unite(self, unite):
        if unite not in self.liste_unites:
            self.liste_unites.append(unite)

    def ajouter_contrat(self, contrat: LeaseContract):
        if contrat not in self.liste_contrats:
            self.liste_contrats.append(contrat)

    def afficher_details(self):
        print(f"Landlord: {self.nom} (ID: {self.id})")
        print("Unités gérées :")
        for unite in self.liste_unites:
            print(f" - {unite.nom}")
        print("Contrats associés :")
        for contrat in self.liste_contrats:
            print(f" - {contrat.id}")
