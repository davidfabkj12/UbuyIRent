from datetime import date, timedelta

class UnitAssignment:
    t = 1
    def __init__(self, unit, contrat, loyerMensuel, dateDebut, dateFin, facturesPrecedentes):
        self.id = self.generer_id()
        self.unit = unit
        self.contrat = contrat
        self.loyerMensuel = loyerMensuel
        self.dateDebut = dateDebut
        self.dateFin = dateFin
        self.facturesPrecedentes = facturesPrecedentes if facturesPrecedentes else []
        self.dateProchaineFacture = self.calculer_prochaine_facture()

    def generer_id(self):
        identifiant = f"UNIT-{UnitAssignment.t:06d}-ASS"
        UnitAssignment.t += 1
        return identifiant

    def calculer_montant_total(self):
        nb_mois = (self.dateFin.year - self.dateDebut.year) * 12 + (self.dateFin.month - self.dateDebut.month)
        return self.loyerMensuel * nb_mois

    def est_en_cours(self):
        today = date.today()
        return self.dateDebut <= today <= self.dateFin

    def calculer_facture_estimee(self):
        if not self.facturesPrecedentes:
            return self.loyerMensuel
        return self.loyerMensuel

    def calculer_prochaine_facture(self):
        if not self.facturesPrecedentes:
            return self.dateDebut
        last_date = self.facturesPrecedentes[-1]
        return last_date + timedelta(days=30)