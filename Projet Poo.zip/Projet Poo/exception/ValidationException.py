class ValidationException(Exception):
    def __init__(self, message):
        super().__init__(f"Erreur de validation : {message}")