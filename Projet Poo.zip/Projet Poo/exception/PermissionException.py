class PermissionException(Exception):
    def __init__(self, utilisateur_nom):
        super().__init__(f"Permission refusée pour l'utilisateur '{utilisateur_nom}' sur cette action")